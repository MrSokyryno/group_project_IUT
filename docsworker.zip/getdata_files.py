import asyncio

from imap_tools import *
from PyPDF2 import PdfReader
from docx import Document
from asyncio import *

class docsworker():

    # Обработка получаемых писем
    def getletters(create_attribute_name):
        data = open(__file__[:-16] + "config.txt", "r")
        with MailBox('imap.gmail.com').login(data.readline()[6:].strip(), data.readline()[10:].strip(), initial_folder='INBOX') as mailbox:
            for msg in mailbox.fetch('(UNSEEN)'):
                print("проверка письма")
                # запись письма в переменные
                subject = msg.subject
                fromper = msg.from_
                toper = "".join(msg.to)
                date = str(msg.date)
                description = msg.text
                filepath = "None"
                text = ""

                # Работа с вложениями, если имеются
                if msg.attachments:
                  for att in msg.attachments:
                      filepath = __file__[:-16] + "mail files/" + att.filename
                      with open(filepath, 'wb') as f:
                          f.write(att.payload)
                      text = text + docsworker.processfile(filepath)
                
                docsworker.create_zipped_file(fromper, toper, date, subject, description, text, create_attribute_name)
        data.close()


    # Создание текстового файла с данными письма
    # параметр create_attribute_name отвечает за показ названий атрибутов в файле
    def create_zipped_file(fromper, toper, date, subject, description, text, create_attribute_name = False):
        newfile = open(__file__[:-16] + "processed files/" + subject + ".txt", "w", encoding="utf-8")
        if create_attribute_name == True:
            newfile.write("subject:" + subject + "\nfromperson:" + fromper + "\ntoperson:" + toper + 
                          "\ndate:" + date + "\n\n" + description  + "\n\n" + text)
            
        else:
            newfile.write(subject + "\n" + fromper + "\n" + toper + "\n" + 
                          date +"\n\n" + description  + "\n\n" + text)

    # преобразует файлы в текст
    def processfile(filepath):
        text = ""
        if filepath.endswith(".txt"):
            with open(filepath, 'r') as f:
                text = f.read()
        elif filepath.endswith(".pdf"):
            with open(filepath, 'rb') as f:
                reader = PdfReader(f)
                for page in reader.pages:
                    text += page.extract_text()
        elif filepath.endswith(".docx"):
            doc = Document(filepath)
            for para in doc.paragraphs:
                text += para.text + "\n"
        text = filepath + "\n" + text
        return text

    # вроде должно работать асинхронно
    async def fulprocessingfiles(create_attribute_name):
        await docsworker.getletters(create_attribute_name)

